abstract class Animal {
    private String _name;
    private String species;
    private int numberOfLegs;

    abstract void speak();

    public Animal(String name, String _species, int numOfLegs) {
        this._name = name;
        this.species = _species;
        this.numberOfLegs = numOfLegs;
    }

    public String name() {
        return this._name;
    }

    public String species() {
        return this.species;
    }

    public int legs() {
        return this.numberOfLegs;
    }
}