public class Hippo extends WildAnimal {

    public Hippo(String name, String _species, int numOfLegs) {
        super(name, _species, numOfLegs);
    }

    public void speak() {
        System.out.println("honk");
    }
    }