package Animal.UltimateAnimal;
import Animal.*
public class Zeppo extends UltimateAnimal {
    
    public Zeppo(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    public Zeppo(int age, int numOfArms) {
        super(age, numOfArms);
    }
}