package Animal.WildAnimal;
importAnimal.*;
public class Skunk extends WildAnimal {

    public Skunk(String name, String _species, int numOfLegs) {
        super(name, _species, numOfLegs);
    }
}