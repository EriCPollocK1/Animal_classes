package DomesticatedAnimal;
import Animal.*

public class DomesticatedAnimal extends Animal {
    public String sku;
    public String toString;

    public DomesticatedAnimal(String _sku, String _toString) {
        this.sku = _sku;
        this.toString = _toString;
    }

    public double unitPrice() {
        return 124.99;
    }

    // Stock Keeping Unit - a unique identifier for cataloging and inventory purposes
    public String sku() {
        return this.sku;
    }

    public String toString() {
        return this.toString;
    }
}