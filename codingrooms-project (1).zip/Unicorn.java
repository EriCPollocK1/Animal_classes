package Animal.UltimateAnimal;
import Animal.*;
public class Unicorn extends UltimateAnimal{
    
    public Unicorn(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    public Unicorn(int age, int numOfArms) {
        super(age, numOfArms);
    }
}
