package Animal.UltimateAnimal;
import Animal.*;
public class Dragon extends UltimateAnimal {
    
    public Dragon(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    public Dragon(int age, int numOfArms) {
        super(age, numOfArms);
    }
}
