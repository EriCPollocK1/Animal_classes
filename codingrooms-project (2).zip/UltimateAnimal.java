public class UltimateAnimal extends Animal {

    public UltimateAnimal(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    private int age;
    private boolean hasGun;
    private int numberOfArms;
   
    public void aging() {
        age ++;
    }

    public void setValue(int _age, int numOfArms) {
        this.age = _age;
        this.numberOfArms = numOfArms;
    }

    public int numberOfArms() {
        return this.numberOfArms;
    }

    public void gun(boolean gun) {
        hasGun = gun;
    }

    public boolean hasGun() {
        return this.hasGun;
    }

    public int getAge() {
        return this.age;
    }

    public String unitPrice() {
        return "not for sale";
    }


}