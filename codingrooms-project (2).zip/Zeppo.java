public class Zeppo extends UltimateAnimal {
    
    public Zeppo(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    @Override
    public void setValue(int age, int numOfArms) {
        super.setValue(age, numOfArms);
    }
}