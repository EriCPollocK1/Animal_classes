public class Dragon extends UltimateAnimal {
    
    public Dragon(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }
    
    @Override
    public void setValue(int age, int numOfArms) {
        super.setValue(age, numOfArms);
    }
}
