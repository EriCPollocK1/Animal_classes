public class DomesticatedAnimal extends Animal {
    private String sku;
    private String toString;

    public DomesticatedAnimal(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    public void setPurchase(String _sku, String _toString) {
        this.sku = _sku;
        this.toString = _toString;
    }

    public double unitPrice() {
        return 124.99;
    }

    // Stock Keeping Unit - a unique identifier for cataloging and inventory purposes
    public String sku() {
        return this.sku;
    }

    public String toString() {
        return this.toString;
    }
}