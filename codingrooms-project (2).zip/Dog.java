public class Dog extends DomesticatedAnimal{
    
    public Dog(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }
    @Override
    public void setPurchase(String sku, String toString) {
        super.setPurchase(sku, toString);
    }
}