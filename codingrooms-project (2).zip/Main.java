/*
Creator: Mr. Lam 2021. Revised by RUniat 2022.
Description:A Program to code Animal classes while learning about OOP concepts.
Starter includes classes: Main, Cat, Dog, Skunk
*/

public class Main {

    public static void main(String[] args) {
        Cat tommy = new Cat("tommy", "Cat", 4);
        Dog spike = new Dog("Spike", "Dog", 2);
        Skunk pierre = new Skunk("Pierre","Skunk",4);
        Hippo jeff = new Hippo("Jeff", "Hippo", 4);
        Zeppo bozo = new Zeppo("Bozo", "Zeppo", 8);
        Dragon Drake = new Dragon("Drake", "Dragon", 4);
        Unicorn Jake = new Unicorn("Jake", "Unicorn", 4);

        // realised after writing this all out that I could have just out it into toString()
        System.out.println(tommy.name() + " " + tommy.species() + " " + tommy.legs());
        System.out.println(spike.name() + " " + spike.species() + " " + spike.legs());
        System.out.println(pierre.name() + " " + pierre.species() + " " + pierre.legs());
        System.out.println(jeff.name() + " " + jeff.species() + " " + jeff.legs());
        System.out.println(bozo.name() + " " + bozo.species() + " " + bozo.legs());
        System.out.println(Drake.name() + " " + Drake.species() + " " + Drake.legs());
        System.out.println(Jake.name() + " " + Jake.species() + " " + Jake.legs());
    }// close main

}
