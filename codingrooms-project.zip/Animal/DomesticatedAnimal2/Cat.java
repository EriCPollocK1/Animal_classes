package DomesticatedAnimal;
import Animal.*;
public class Cat extends DomesticatedAnimal{
    
    public Cat(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    public Cat(String sku, String toString) {
        super(sku, toString);
    }
}