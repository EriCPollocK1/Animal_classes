package DomesticatedAnimal;
import Animal.*;
public class Dog extends DomesticatedAnimal{
    
    public Dog(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    public Dog(String sku, String toString) {
        super(sku, toString);
    }
}