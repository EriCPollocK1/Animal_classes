package Animal;

public class Animal {
    public String _name;
    public String species;
    public int numberOfLegs;

    public Animal(String name, String _species, int numOfLegs) {
        this._name = name;
        this.species = _species;
        this.numberOfLegs = numOfLegs;
    }

    public Animal(boolean gun) {
    }

    public Animal(int _age, int numOfArms) {
    }

    public Animal(String _sku, String _toString) {
    }

    public String name() {
        return this._name;
    }

    public String species() {
        return this.species;
    }

    public int legs() {
        return this.numberOfLegs;
    }
}
