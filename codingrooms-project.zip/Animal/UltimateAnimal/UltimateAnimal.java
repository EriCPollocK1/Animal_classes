package Animal.UltimateAnimal;
import Animal.*;

public class UltimateAnimal extends Animal {

    public UltimateAnimal(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    public int age;
    public boolean hasGun;
    public int numberOfArms;
   
    public void aging() {
        age ++;
    }

    public UltimateAnimal(int _age, int numOfArms) {
        super(_age, numOfArms);
        this.age = _age;
        this.numberOfArms = numOfArms;
    }

    public int numberOfArms() {
        return this.numberOfArms;
    }

    public UltimateAnimal(boolean gun) {
        super(gun);
        hasGun = gun;
    }

    public boolean hasGun() {
        return this.hasGun;
    }

    public int getAge() {
        return this.age;
    }

    public String unitPrice() {
        return "not for sale";
    }


}