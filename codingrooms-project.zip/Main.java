/*
Creator: Mr. Lam 2021. Revised by RUniat 2022.
Description:A Program to code Animal classes while learning about OOP concepts.
Starter includes classes: Main, Cat, Dog, Skunk
*/

import Animal.*;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("hi");
        Cat tommy = new Cat("cat0001", "Cat's name is tommy");
        Dog spike = new Dog("Dog0101", "Dog's name is spike");
        Skunk pierre = new Skunk("Pierre","Skunk",4);
        Hippo jeff = new Hippo("Jeff", "Hippo", 4);
        Zeppo bozo = new Zeppo("Bozo", "Zeppo", 8);
        Dragon Drake = new Dragon("Drake", "Dragon", 4);
        Unicorn Jake = new Unicorn("Jake", "Unicorn", 4);

        System.out.println(tommy.name());
        System.out.println(tommy.species());
        System.out.println(tommy.legs());
        System.out.println(spike.name());
        System.out.println(spike.species());
    }// close main

}
