package Animal.WildAnimal;
import Animal.Animal;
abstract class WildAnimal extends Animal{

    public WildAnimal(String name, String _species, int numOfLegs) {
        super(name, _species, numOfLegs);
    }

    public String toString() {
        return name() + " " + species() + " " + legs();
    }
    }