package Animal.WildAnimal;
import Animal.Animal;
public class Skunk extends WildAnimal {

    public Skunk(String name, String _species, int numOfLegs) {
        super(name, _species, numOfLegs);
    }

    public void speak() {
        System.out.println("Hiss");
    }
}