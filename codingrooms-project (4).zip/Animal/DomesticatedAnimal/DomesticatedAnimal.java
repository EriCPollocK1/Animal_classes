package Animal.DomesticatedAnimal;
import Animal.Animal;
abstract class DomesticatedAnimal extends Animal {
    private String sku;
    private String toString;
    protected double unitPrice;

    public DomesticatedAnimal(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }

    public void setPurchase(String _sku) {
        this.sku = _sku;
    }

    public void setPrice(double price) {
        this.unitPrice = price;
    }

    public double unitPrice() {
        return this.unitPrice;
    }

    // Stock Keeping Unit - a unique identifier for cataloging and inventory purposes
    public String sku() {
        return this.sku;
    }

    public String toString() {
        return name() + " " + species() + " " + legs();
    }
}