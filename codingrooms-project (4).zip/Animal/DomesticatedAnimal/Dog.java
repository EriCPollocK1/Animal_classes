package Animal.DomesticatedAnimal;
import Animal.Animal;
public class Dog extends DomesticatedAnimal{
    
    public Dog(String name, String species, int numOfLegs) {
        super(name, species, numOfLegs);
    }
    @Override
    public void setPurchase(String sku) {
        super.setPurchase(sku);
    }

    public void speak() {
        System.out.println("Woof");
    }
}