/*
Creator: Mr. Lam 2021. Revised by RUniat 2022.
Description:A Program to code Animal classes while learning about OOP concepts.
Starter includes classes: Main, Cat, Dog, Skunk
*/
import Animal.UltimateAnimal.*;
import Animal.DomesticatedAnimal.*;
import Animal.WildAnimal.*;
import Animal.*;

public class Main {

    public static void main(String[] args) {
        Cat tommy = new Cat("Tommy", "Cat", 4);
        Cat tom = new Cat("Tom", "Cat", 4);
        Dog spike = new Dog("Spike", "Dog", 2);
        Skunk pierre = new Skunk("Pierre","Skunk",4);
        Hippo jeff = new Hippo("Jeff", "Hippo", 4);
        Zeppo bozo = new Zeppo("Bozo", "Zeppo", 8);
        Dragon Drake = new Dragon("Drake", "Dragon", 4);
        Unicorn Jake = new Unicorn("Jake", "Unicorn", 4);

        System.out.println(tommy.toString());
        System.out.println(tom.toString());
        System.out.println(spike.toString());
        System.out.println(pierre.toString());
        System.out.println(jeff.toString());
        System.out.println(bozo.toString());
        System.out.println(Drake.toString());
        System.out.println(Jake.toString());
    }// close main

}
